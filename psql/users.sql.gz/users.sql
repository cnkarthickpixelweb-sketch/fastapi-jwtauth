-- Adminer 5.4.1 PostgreSQL 18.1 dump

DROP TABLE IF EXISTS "users";
DROP SEQUENCE IF EXISTS users_id_seq;
CREATE SEQUENCE users_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."users" (
    "id" integer DEFAULT nextval('users_id_seq') NOT NULL,
    "firstname" text NOT NULL,
    "lastname" text NOT NULL,
    "email" text NOT NULL,
    "password" text NOT NULL,
    "profile_image" text,
    "created_at" date DEFAULT now(),
    "updated_at" timestamp DEFAULT now(),
    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
)
WITH (oids = false);

INSERT INTO "users" ("id", "firstname", "lastname", "email", "password", "profile_image", "created_at", "updated_at") VALUES
(4,	'teddy',	'cup',	'teddycup@mailinator.com',	'$argon2id$v=19$m=65536,t=3,p=4$fi+ldM65V2rNmZNSqnUO4Q$WHew3BdZTLyDGeel45C7EdTe1ClWZKVQscLH5QRlCCw',	'profile_images/dol.jpeg',	'2026-01-13',	'2026-01-13 13:15:14.663089');

-- 2026-01-13 11:51:59 UTC
